package com.everis.model;


import lombok.Data;

@Data
public class Region {
    private Long id;
    private String name;
}
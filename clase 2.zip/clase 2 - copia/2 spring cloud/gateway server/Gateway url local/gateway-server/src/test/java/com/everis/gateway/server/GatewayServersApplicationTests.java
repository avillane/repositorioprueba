package com.everis.gateway.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayServersApplicationTests {

	@Test
	void contextLoads() {
	}

}
